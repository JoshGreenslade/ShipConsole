namespace Ship.EventSystem;

public class Event { }