namespace Ship.Modules;

using Ship.Entities;

public class ShipModule : Entity { }