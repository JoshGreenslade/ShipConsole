namespace Ship.Components;

public class Component { }