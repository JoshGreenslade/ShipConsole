namespace Ship.Systems;

public class System { }